import React, { useEffect } from "react";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
import {
  getAllEmployees,
  deleteEmployee,
} from "../redux/actions/employeeActions";

const AllEmployee = ({ getAllEmployees, employees, deleteEmployee }) => {
  useEffect(() => {
    getAllEmployees();
  }, [getAllEmployees]);

  const goToUpdateForm = (emp) => {};

  return (
    <div>
      <table className="table table-bordered">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Emp Id</th>
            <th scope="col">First Name</th>
            <th scope="col">Last Name</th>
            <th scope="col">Email</th>
            <th scope="col">Actions</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((emp, index) => (
            <tr key={index}>
              <th>{index + 1}</th>
              <td>{emp.id}</td>
              <td>{emp.firstName}</td>
              <td>{emp.lastName}</td>
              <td>{emp.email}</td>
              <td>
                <div className="d-flex justify-content-center">
                  <button
                    onClick={() => goToUpdateForm(emp)}
                    className="btn border m-1 btn-sm"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => deleteEmployee(emp)}
                    className="btn border m-1 btn-sm"
                  >
                    Delete
                  </button>
                  <button className="btn border m-1 btn-sm">View</button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const mapStateToProps = (state) => ({
  employees: state.employee,
});

const mapDispatchToProps = { getAllEmployees, deleteEmployee };

export default connect(mapStateToProps, mapDispatchToProps)(AllEmployee);
