import React, { Fragment } from "react";
import { connect } from "react-redux";
import { Route, Switch } from "react-router-dom";
import AddEmployee from "./AddEmployee";
import AllEmployee from "./AllEmployee";
function Routes({ alert }) {
  return (
    <div className="container mt-3">
      {alert.alertType && (
        <pre className={"alert alert-" + alert.alertType}>{alert.message}</pre>
      )}
      <Fragment>
        <Switch>
          <Route exact path="/" component={AllEmployee}></Route>
          <Route exact path="/add-employee" component={AddEmployee}></Route>
        </Switch>
      </Fragment>
    </div>
  );
}

const mapStateToProps = (state) => ({
  alert: state.alert,
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(Routes);
