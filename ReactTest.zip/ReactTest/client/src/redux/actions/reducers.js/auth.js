import { ADD_EMPLOYEE, DELETE_EMPLOYEE, GET_ALL_EMPLOYEE, UPDATE_EMPLOYEE } from "../reactactions/types";

  
  const initialState = [];
  
  export default (state = initialState, { type, payload }) => {
    switch (type) {
      case UPDATE_EMPLOYEE:
        return [...state];
      case ADD_EMPLOYEE:
        return [...state, payload];
  
      case DELETE_EMPLOYEE:
        console.log({ payload, state });
        return state.filter((emp) => emp != payload);
  
      case GET_ALL_EMPLOYEE:
        return [...payload];
  
      default:
        return state;
    }
  };
  